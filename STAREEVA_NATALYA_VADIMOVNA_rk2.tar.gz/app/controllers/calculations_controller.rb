# frozen_string_literal: true

# Controller responsible for handling calculations.
class CalculationsController < ApplicationController
  def index
    # значения по умолчанию
    @arr_l = [0.05, 2, 3, 4, 5, 6, 7, 0.05, 9, 10, 11, 12, 13, 14, 0.05, 16, 17, 18, 19, 20]
    @result = calculate_result(@arr_l)
  end

  private

  def calculate_result(arr)
    # логика вычислений
    min_element = arr.min
    max_element = arr.max
    quotient = min_element.to_f / max_element

    # обновление массива с учетом условия
    arr.map.with_index do |elem, idx|
      if ((idx + 1) % 7).zero?
        quotient
      else
        elem
      end
    end
  end
end
