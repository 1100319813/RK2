require 'test_helper'

class CalculationsControllerTest < ActionController::TestCase
  test 'should get index' do
    get :index
    assert_response :success
  end

  test 'should calculate result with valid input' do
    valid_input = [0.05, 2, 3, 4, 5, 6, 7, 0.05, 9, 10, 11, 12, 13, 14, 0.05, 16, 17, 18, 19, 20]
    get :index, params: { arr_l: valid_input }

    assert_response :success
    assert_template :index
    assert_not_nil assigns(:arr_l)
    assert_not_nil assigns(:result)
  end
end
