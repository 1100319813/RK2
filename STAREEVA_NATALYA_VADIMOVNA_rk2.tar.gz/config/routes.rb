Rails.application.routes.draw do
  get 'calculations/index', as: 'calculations_path'
  root 'calculations#index'
end
